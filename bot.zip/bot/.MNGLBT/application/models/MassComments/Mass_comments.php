<?php defined('BASEPATH') OR exit('No direct script access allowed');



class Mass_comments extends CI_Model {
  public function __construct()
  {
   parent::__construct();
  }

  public function reset_data()
  {
    /*
      @Array data
    */
    $this->data = [];
    /*
      @Array params
    */
    $this->params = [];
  }

  public function index()
  {
    foreach ($this->configs->show_menu_mass_comments() as $menu)
    {
      $this->climate->out("    [{$this->yellow}{$menu->no}{$this->reset}]. $menu->name");
    }
    $input = $this->climate->br()->input('  Сонгох:');
    $input = $input->prompt();
    switch ($input)
    {
      case '01':
        $this->input_home();
        break;
      case '02':
        $this->input_friends();
        break;
      case '03':
        $this->input_groups();
        break;
      case '04':
        $this->input_fanspage();
        break;
      case '0':
        $this->return_menu->index();
        exit(0);
      default:
        $this->climate->br()->shout('  Алдаатай өгөгдөл');
        sleep(3);
        $this->tools->mass_react('Спамм Реакт');
        break;
    }
    $this->climate->br();
    $this->dump_post();
  }

  private function input_home()
  {
    $this->url = $this->base_url.'/home.php';
    $this->climate->br()->shout("  Шинэ мөр авах бол '<n>' ")->br();
    $input = $this->climate->input('  Бичвэр:');
    $this->msg = $input->prompt();
    if (!trim($this->msg))
    {
      $this->climate->br()->shout('  Алдаатай бичвэр');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
    $input = $this->climate->input('  Хэдэн удаа? (ЖШ: 10):');
    $this->limit = $input->prompt();
    if (!is_numeric($this->limit) OR $this->limit == '0')
    {
      $this->climate->br()->shout('  Буруу өгөгдөл');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
  }

  private function input_friends()
  {
    $input = $this->climate->br()->input('  Ашиглагчийн нэр эсвэл ID:');
    $username = $input->prompt();
    if (!trim($username))
    {
      $this->climate->br()->shout('  Ашиглагчийн нэр эсвэл ID');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
    $this->url = $this->base_url.'/'.$username.'?v=timeline';
    $this->climate->br()->shout("  Шинэ мөр бол '<n>'ЖШ: hello<n>world")->br();
    $input = $this->climate->input('  Бичвэр:');
    $this->msg = $input->prompt();
    if (!trim($this->msg))
    {
      $this->climate->br()->shout('  Бичвэр');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
    $input = $this->climate->input('  Хэдэн удаа (ЖШ: 10):');
    $this->limit = $input->prompt();
    if (!is_numeric($this->limit) OR $this->limit == '0')
    {
      $this->climate->br()->shout('  Буруу өгөгдөл');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
  }

  private function input_groups()
  {
    $this->climate->br()->info('  Групп-д орсон байх ёстойг анхаарна уу ')->br();
    $input = $this->climate->input('  Групп id:');
    $id = $input->prompt();
    if (!is_numeric($id))
    {
      $this->climate->br()->shout(' Зөв id хийнэ үү id');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
    $this->url = $this->base_url.'/groups/'.$id;
    $this->climate->br()->shout("  Шинэ мөр бол'<n>' ЖШ: hello<n>world")->br();
    $input = $this->climate->input('  Бичвэр:');
    $this->msg = $input->prompt();
    if (!trim($this->msg))
    {
      $this->climate->br()->shout('  Зав бичвэр');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
    $input = $this->climate->input('  Хэдэн удаа(ЖШ: 10):');
    $this->limit = $input->prompt();
    if (!is_numeric($this->limit) OR $this->limit == '0')
    {
      $this->climate->br()->shout('  Буруу өгөгдөл');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
  }

  private function input_fanspage()
  {
    $input = $this->climate->br()->input('  ID эсвэл ашиглагчийн нэр:');
    $username = $input->prompt();
    if (!trim($username))
    {
      $this->climate->br()->shout('  Зөв өгөгдөл өгнө үү');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
    $this->url = $this->base_url.'/'.$username;
    $this->climate->br()->shout("  Шинэ мөр бол '<n>' ЖШ: hello<n>world")->br();
    $input = $this->climate->input('  Бичвэр:');
    $this->msg = $input->prompt();
    if (!trim($this->msg))
    {
      $this->climate->br()->shout('  Зөв бичвэр хийнэ үү');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
    $input = $this->climate->input('  Хэдэн удаа (ЖШ: 10):');
    $this->limit = $input->prompt();
    if (!is_numeric($this->limit) OR $this->limit == '0')
    {
      $this->climate->br()->shout('  Алдаатай өгөгдөл');
      sleep(3);
      $this->tools->mass_comments('Спамм сэтгэгдэл');
    }
  }

  private function dump_post()
  {
    $stop = false;
    $response = $this->configs->request_get($this->url, $this->cookies);
    $dom = new DOMDocument();
    @$dom->loadHTML($response);
    foreach ($dom->getElementsByTagName('a') as $href)
    {
      $hrefs = $href->getAttribute('href');
      if (trim($href->nodeValue) == 'Berita Lengkap')
      {
        $this->data[] = $this->base_url.$hrefs;
        $this->climate->inline("\r  GET (".count($this->data).") post...");
        if ($this->limit == count($this->data) OR count($this->data) > $this->limit)
        {
          $stop = true;
          break;
        }
      }
    }
    if (!$stop)
    {
      foreach ($dom->getElementsByTagName('a') as $href)
      {
        $hrefs = $href->getAttribute('href');
        if (strpos($href->nodeValue, 'Lihat Berita Lain') !== false)
        {
          $this->url = $this->base_url.$hrefs;
          $this->dump_post();
          break;
        }
        else if (strpos($href->nodeValue, 'Tampilkan lainnya') !== false)
        {
          $this->url = $this->base_url.$hrefs;
          $this->dump_post();
          break;
        }
        else if (strpos($href->nodeValue, 'Lihat Postingan Lainnya') !== false)
        {
          $this->url = $this->base_url.$hrefs;
          $this->dump_post();
          break;
        }
      }
    }
    if (count($this->data) !== 0)
    {
      $this->climate->br()->br()->shout('  Ажиллаж байна...')->br();
      foreach ($this->data as $post)
      {
        $this->comments($post);
      }
      $this->climate->br()->out('  Амжилттай Дууслаа Баярлалаа:3');
      $this->configs->back_menu();
    }
    else
    {
      $this->climate->shout('  Пост олдсонгүй');
      $this->configs->back_menu();
    }
  }

  private function comments($post_url)
  {
    preg_match('/:top_level_post_id.(.*?):tl_objid..*?:content_owner_id_new.(.*?):/', urldecode($post_url), $post_id);
    if (count($post_id) !== 3)
    {
      preg_match('/:top_level_post_id.(.*?):content_owner_id_new.(.*?):/', urldecode($post_url), $post_id);
    }
    if (count($post_id) == 3)
    {
      $this->post_ids = $post_id[2].'_'.$post_id[1];
    }
    else
    {
      $this->post_ids = 'Буруу пост id';
    }
    $response = $this->configs->request_get($post_url, $this->cookies);
    $dom = new DOMDocument();
    @$dom->loadHTML($response);
    $this->params = [];
    foreach ($dom->getElementsByTagName('form') as $form)
    {
      $action = $form->getAttribute('action');
      if (strpos($action, '/a/comment.php?') !== false)
      {
        $this->params['action'] = $this->base_url.$action;
        break;
      }
    }
    foreach ($dom->getElementsByTagName('input') as $input)
    {
      $name = $input->getAttribute('name');
      $value = $input->getAttribute('value');
      if (trim($name) == 'fb_dtsg')
      {
        $this->params['fb_dtsg'] = $value;
      }
      if (trim($name) == 'jazoest')
      {
        $this->params['jazoest'] = $value;
        break;
      }
    }
    if (count($this->params) == 3)
    {
      $this->execute($this->params['action']);
    }
    else
    {
      $this->climate->out("  + {$this->post_ids} - Error when grab value");
    }
  }

  private function execute($url)
  {
    unset($this->params['action']);
    $this->params['comment_text'] = str_replace("<n>", "\n", $this->msg);
    $post_data = http_build_query($this->params);
    $this->configs->request_post($url, $this->cookies, $post_data);
    $this->climate->out("  + {$this->post_ids} - Амжилттай сэтгэгдэл бичлээ..");
  }
}