<?php defined('BASEPATH') OR exit('No direct script access allowed');



class Friends_request extends CI_Model {

  public function __construct()
  {
    parent::__construct();
  }

  public function reset_data()
  {
    /*
      @Array data
    */
    $this->data = [];
    $this->url = $this->base_url.'/friends/center/requests/';
  }

  public function ask_input()
  {
    $this->climate->info("  (?) Найзын хүсэлт Авах бол A , Устгах Бол D ")->br();
    $input = $this->climate->input("  [{$this->yellow}A{$this->reset}]accept эсвэл [{$this->yellow}D{$this->reset}]elete:");
    $input = $input->prompt();
    if (strtolower($input) == 'a')
    {
      $this->msg = 'Permintaan diterima';
      $this->type = 'Konfirmasi';
    }
    else if (strtolower($input) == 'd')
    {
      $this->msg = 'Permintaan dihapus';
      $this->type = 'Hapus Permintaan';
    }
    else
    {
      $this->climate->br()->shout('  Алдаатай өгөгдөл!');
      exit(0);
    }
    $this->climate->br();
  }

  public function index()
  {
    $response = $this->configs->request_get($this->url, $this->cookies);
    $dom = new DOMDocument();
    @$dom->loadHTML($response);
    foreach ($dom->getElementsByTagName('a') as $href)
    {
      $hrefs = $href->getAttribute('href');
      if (strpos($hrefs, '/friends/hovercard/mbasic/') !== false)
      {
        $name = $href->nodeValue;
      }
      if (strpos($href->nodeValue, $this->type) !== false)
      {
        if ($this->type == 'Konfirmasi')
        {
          preg_match('/\/a\/notifications.php\?confirm=(.*?)&/', $hrefs, $ids);
        }
        else
        {
          preg_match('/\/a\/notifications.php\?delete=(.*?)&/', $hrefs, $ids);
        }
        $this->data[] = [
          'url' =>$this->base_url.$hrefs,
          'name' => $name,
          'uid' => $ids[1]
        ];
        $this->climate->inline("\r  Цуглуулж (".count($this->data).") байна...");
      }
    }
    foreach ($dom->getElementsByTagName('a') as $href)
    {
      $hrefs = $href->getAttribute('href');
      if (strpos($href->nodeValue, 'Lihat selengkapnya') !== false)
      {
        $this->url = $this->base_url.$hrefs;
        $this->index();
        break;
      }
    }
    if (count($this->data) !== 0)
    {
      $this->climate->br()->br()->shout('  Эхэлж байна...')->br();
      $this->execute();
    }
    else
    {
      $this->climate->shout('  Өгөгдөл алга!');
      $this->configs->back_menu();
    }
  }

  public function execute()
  {
    foreach ($this->data as $req)
    {
      $response = $this->configs->request_get($req['url'], $this->cookies);
      if ($this->type == 'Konfirmasi')
      {
        if (strpos($response, $this->msg) !== false)
        {
          $this->climate->out('  [Зөвшөөрсөн] '.$req['uid'].' - '.$req['name']);
        }
        else
        {
          $this->climate->out('  [Амжилтгүй] '.$req['uid'].' - '.$req['name']);
        }
      }
      else
      {
        if (strpos($response, $this->msg) !== false)
        {
          $this->climate->out('  [Устсан] '.$req['uid'].' - '.$req['name']);
        }
        else
        {
          $this->climate->out('  [Амжилтгүй] '.$req['uid'].' - '.$req['name']);
        }
      }
    }
    $this->climate->br()->out('  Амжилттай Дууслаа баярлалаа:3');
    $this->configs->back_menu();
  }
}