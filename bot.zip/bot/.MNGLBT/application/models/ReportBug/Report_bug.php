<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Report_bug extends CI_Model {

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $this->climate->info('  Түүл ажиллахгүй байна уу?')->br();
    $input = $this->climate->input('  Таны нэр:');
    $this->name = $input->prompt();
    if (!trim($this->name))
    {
      $this->climate->br()->shout('  Нэрээ бичнэ үү');
      sleep(3);
      $this->tools->report_bug('Алдаа мэдээллэх');
    }
    $input = $this->climate->input('  Таны мэйл хаяг:');
    $this->email = $input->prompt();
    if (!filter_var($this->email, FILTER_VALIDATE_EMAIL))
    {
      $this->climate->br()->shout('  Зөв бичнэ үү');
      sleep(3);
      $this->tools->report_bug('Алдаа мэдээллэх');
    }
    $input = $this->climate->input('  Таны бичвэр:');
    $this->msg = $input->prompt();
    if (!trim($this->msg))
    {
      $this->climate->br()->shout('  Бичэх зүлээ бичнэ үү');
      sleep(3);
      $this->tools->report_bug('Алдаа мэдээллэх');
    }
    $this->send();
    $this->configs->back_menu();
  }

  private function send()
  {
    $post_data = http_build_query(
      [
        'name' => $this->name,
        'email' => $this->email,
        'messages' => $this->msg
      ]
    );
    $ch = curl_init('https://dz-tools.my.id/api/bug-report-cli');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
      $this->climate->br()->shout('  Холболтын алдаа холболтоо шалгана уу.');
      exit(0);
    }
    curl_close($ch);
    $decode = json_decode($response);
    if (isset($decode->error) and $decode->error == false)
    {
      $this->climate->br()->info('  Баярлалаа');
    }
    else
    {
       $this->climate->br()->shout('  Амжилтгүй');
    }
  }
}