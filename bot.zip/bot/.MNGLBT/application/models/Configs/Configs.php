<?php defined('BASEPATH') OR exit('No direct script access allowed');



class Configs extends CI_Model {

  public function __construct() {
    parent::__construct();
    /*
      @Banner please don't remove the author name
    */
    $this->banner = PHP_EOL."
{$this->yellow}                         \ \ {$this->reset}| {$this->yellow}* %s
{$this->yellow}    .-'''''-.    __       |/ {$this->reset}|----------------------------
{$this->yellow}   /         \.'`  `',.--//  {$this->reset}| {$this->yellow}* Монгол Бот [{$this->red}MNGLBT{$this->yellow}]
{$this->yellow} -(      {$this->red}MNGL{$this->yellow} | {$this->red}BOT{$this->yellow}  |  @@\  {$this->reset}| {$this->yellow}* Зохиогч : Kira
{$this->yellow}   \         /'.____.'\___|  {$this->reset}| {$this->yellow}* GitHub    : github.com/kirashishigami
{$this->yellow}    '-.....-' __/ | \   (`)  {$this->reset}|----------------------------
{$this->reset}    v1.1 dev{$this->yellow} /   /  /        {$this->reset}| {$this->yellow}* %s
{$this->yellow}                 \  \ \n{$this->reset}".PHP_EOL;
    /*
      @Load modules climate
    */
    include('vendor/autoload.php');
    $this->cli = new League\CLImate\CLImate;
  }

  public function banner() {
    /*
      @Banner please don't remove the author name
    */
    return $this->banner;
  }

  public function clear() {
    if (strtolower(substr(PHP_OS, 0, 3)) === 'lin') {
      system('clear');
    } else
    {
      system('cls');
    }
  }

  public function back_menu() {
    $input = $this->climate->br()->input("  {$this->yellow}Enter дарж буцна уу...{$this->reset}");
    $input->prompt();
    $this->return_menu->index();
  }

  public function load_cookies() {
    if (file_exists('log/cookies.txt') and filesize('log/cookies.txt') > 0) {
      /*
      @Read Cookies
      */
      $file = fopen('log/cookies.txt', 'r');
      $cookies = fgets($file);
      fclose($file);
      return $cookies;
    } else
    {
      return false;
    }
  }

  public function list_captions($file) {
    $caption = [];
    $file = fopen('random/'.$file, 'r');
    while (!feof($file)) {
      if (trim(fgets($file))) {
        $caption[] = trim(fgets($file));
      }
    }
    fclose($file);
    return $caption;
  }

  public function climate() {
    return $this->cli;
  }

  public function request_get($url, $cookies = false) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, TRUE);
    curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
    curl_setopt($ch, CURLOPT_COOKIE, $cookies);
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
      $this->climate->br()->shout('  Холболтын алдаа Интернэт холболтоо шалгаад дахин орно уу.');
      exit(0);
    }
    curl_close($ch);
    return $response;
  }

  public function request_post($url, $cookies = false, $post) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_USERAGENT, $this->user_agent);
    curl_setopt($ch, CURLOPT_COOKIE, $cookies);
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
      $this->climate->br()->shout('  Холболтын алдаа Интернэт холболтоо шалгаад дахин орно уу.');
      exit(0);
    }
    curl_close($ch);
    return $response;
  }

  public function show_menu() {
    $menu = json_encode(
      array(
        ['no' => '01', 'name' => 'Чат устгах'],
        ['no' => '02', 'name' => 'Бүх пост устгах'],
        ['no' => '03', 'name' => 'Бүх найзууд хасах'],
        ['no' => '04', 'name' => 'Зураг устгах'],
        ['no' => '05', 'name' => 'Найзын хүсэлт зөвшөөрөх эсвэл устгах'],
        ['no' => '06', 'name' => 'Дурын өгсөн нэрээр группууд руу орох'],
        ['no' => '07', 'name' => 'Энэ хэсэг боломжгүй'],
        ['no' => '08', 'name' => 'Бүх найзууд руу чат бичих'],
        ['no' => '09', 'name' => '1 хүн рүү чат бичих'],
        ['no' => '10', 'name' => 'Бүх группээс гарах'],
        ['no' => '11', 'name' => 'Реакт дарах'],
        ['no' => '12', 'name' => 'Сэтгэгдэл спамм хийх'],
        ['no' => '13', 'name' => 'Сэтгэгдэл спамм хийх нэг пост'],
        ['no' => '14', 'name' => 'Бүх групп-д пост хийх'],
        ['no' => '15', 'name' => 'Яавуулсан хүсэлтээ буцаах'],
        ['no' => '16', 'name' => 'Бүх блоклсон хүмүүсээ буцаах'],
      )
    );
    return json_decode($menu);
  }

  public function show_menu_update_status() {
    $menu = json_encode(
      array(
        ['no' => '01', 'name' => 'Status ....'],
        ['no' => '02', 'name' => 'Status ....'],
        ['no' => '03', 'name' => 'Status ....'],
        ['no' => '00', 'name' => 'Буцах'],
      )
    );
    return json_decode($menu);
  }

  public function show_menu_mass_react() {
    $menu = json_encode(
      array(
        ['no' => '01', 'name' => 'Өөрийн пост дээр'],
        ['no' => '02', 'name' => 'Найзуудын пост дээр'],
        ['no' => '03', 'name' => 'Группын пост дээр'],
        ['no' => '04', 'name' => 'Пэн пайжэ дээр'],
        ['no' => '00', 'name' => 'Буцах'],
      )
    );
    return json_decode($menu);
  }

  public function show_menu_reactions() {
    $menu = json_encode(
      array(
        ['no' => '01', 'name' => 'Like'],
        ['no' => '02', 'name' => 'Love'],
        ['no' => '03', 'name' => 'Care'],
        ['no' => '04', 'name' => 'HaHa'],
        ['no' => '05', 'name' => 'Wow'],
        ['no' => '06', 'name' => 'Sad'],
        ['no' => '07', 'name' => 'Angry'],
        ['no' => '00', 'name' => 'Буцах'],
      )
    );
    return json_decode($menu);
  }

  public function show_menu_mass_comments() {
    $menu = json_encode(
      array(
        ['no' => '01', 'name' => 'Өөрийн пост дээр'],
        ['no' => '02', 'name' => 'Найзуудын пост дээр'],
        ['no' => '03', 'name' => 'Группын пост дээр'],
        ['no' => '04', 'name' => 'Пэн пайжэ дээр'],
        ['no' => '00', 'name' => 'Буцах'],
      )
    );
    return json_decode($menu);
  }
}