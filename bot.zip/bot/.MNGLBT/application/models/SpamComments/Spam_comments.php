<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Spam_comments extends CI_Model {

  public function __construct()
  {
    parent::__construct();
  }

  public function index()
  {
    $input = $this->climate->input('  Пост линк:');
    $post = $input->prompt();
    if (!filter_var($post, FILTER_VALIDATE_URL))
    {
      $this->climate->br()->shout('  Зөв хийнэ үү.');
      sleep(3);
      $this->tools->spam_comments('Спамм сэтгэгдэл');
    }
    $this->post = str_replace(parse_url($post)['host'], 'mbasic.facebook.com', $post);
    $this->climate->br()->shout("  ?: Use '<n>' for new lines")->br();
    $input = $this->climate->input('  Бичвэр:');
    $this->msg = $input->prompt();
    if (!trim($this->msg))
    {
      $this->climate->br()->shout('  Энд бичвэр бичнэ үү');
      sleep(3);
      $this->tools->spam_comments('Спамм сэтгэгдэл');
    }
    $input = $this->climate->input('  Хэдэн удаа (ЖШ: 10):');
    $this->limit = $input->prompt();
    if (!is_numeric($this->limit) OR $this->limit == 0)
    {
      $this->climate->br()->shout('  Буруу дугаар.');
      sleep(3);
      $this->tools->spam_comments('Спамм сэтгэгдэл');
    }
    $this->climate->br();
    $this->data = $this->get_csrf();
    $this->comments();
  }

  private function get_csrf()
  {
    $response = $this->configs->request_get($this->post, $this->cookies);
    $dom = new DOMDocument();
    @$dom->loadHTML($response);
    $data = [];
    foreach ($dom->getElementsByTagName('form') as $form)
    {
      $action = $form->getAttribute('action');
      if (strpos($action, '/a/comment.php?') !== false)
      {
        $data['action'] = $action;
        break;
      }
    }
    foreach ($dom->getElementsByTagName('input') as $input)
    {
      $name = $input->getAttribute('name');
      $value = $input->getAttribute('value');
      if (trim($name) == 'fb_dtsg')
      {
        $data['fb_dtsg'] = $value;
      }
      if (trim($name) == 'jazoest')
      {
        $data['jazoest'] = $value;
        break;
      }
    }
    if (count($data) == 3)
    {
      return $data;
    }
    else
    {
      return [];
    }
  }

  private function comments()
  {
    if (count($this->data) == 3)
    {
      $loop = 0;
      for ($i = 0; $i < $this->limit; $i++)
      {
        $loop++;
        $o = str_pad($loop, 2, '0', STR_PAD_LEFT);
        $url = $this->base_url.$this->data['action'];
        $this->data['comment_text'] = str_replace("<n>", "\n", $this->msg);
        $params = http_build_query($this->data);
        $this->configs->request_post($url, $this->cookies, $params);
        $this->climate->out("  [{$this->yellow}{$o}{$this->reset}] Сэтгэгдэл амжилттай бичлээ.");
      }
      $this->climate->br()->out('  Амжилттай Дууслаа Баярлалаа:3');
      $this->configs->back_menu();
    }
    else
    {
      $this->climate->shout('  Пост олдсонгүй :(');
      $this->configs->back_menu();
    }
  }
}